//********************************************************************
// INCLUDE FILES
//====================================================================
#define STM32F051
#include <stm32f0xx.h>
#include <stm32f051x8.h>
#include "lcd_stm32f0.c"
//====================================================================
// GLOBAL CONSTANTS
//====================================================================

//====================================================================
// GLOBAL VARIABLES
//====================================================================
uint16_t ADC_value_left;
uint16_t ADC_value_front;
uint16_t ADC_value_right;

uint16_t frontThreshold = 2400;
uint16_t frontOffThreshold = 1700;
uint16_t leftThreshold = 2800;
uint16_t leftOffThreshold = 2100;
uint16_t rightThreshold = 2700;
uint16_t rightOffThreshold = 2200;

//====================================================================
// FUNCTION DECLARATIONS
//====================================================================
void init_GPIOA(void);
void init_GPIOB(void); 
void init_ADC(void); 
void adcLCDdisplay(uint16_t number);

//====================================================================
// MAIN FUNCTION
//====================================================================
int main(void) {
    init_GPIOA();
    init_GPIOB();
    init_ADC();
    init_LCD();


    while(1) {
        /*
            read ADC for left sensor
        */
        ADC1->CHSELR  |=  ADC_CHSELR_CHSEL0;  // select ADC channel 0(for ADC_IN0 = PA0)
        ADC1->CR  |=  ADC_CR_ADSTART;  // start conversion
        while( (ADC1->ISR & ADC_ISR_EOC) == 0 );  // wait until conversion is complete
        ADC_value_left = ADC1->DR;
        ADC1->CHSELR  &= ~ADC_CHSELR_CHSEL0;  // deselect ADC channel 0


        if (ADC_value_left > leftThreshold){
            GPIOB -> ODR |= GPIO_ODR_7;     //turn PB7 led on

        }else{
            if (ADC_value_left < leftOffThreshold){
            GPIOB -> ODR &= ~GPIO_ODR_7;    //turn PB7 led off
            } else {
            GPIOB -> ODR &= ~GPIO_ODR_7;
            }
        }
        
        /*
            read ADC for front sensor
        */
        ADC1->CHSELR  |=  ADC_CHSELR_CHSEL1;  // select ADC channel 1(for ADC_IN1 = PA1)
        ADC1->CR  |=  ADC_CR_ADSTART;  // start conversion
        while( (ADC1->ISR & ADC_ISR_EOC) == 0 );  // wait until conversion is complete
        ADC_value_front = ADC1->DR;
        ADC1->CHSELR  &= ~ADC_CHSELR_CHSEL1; // deselect ADC channel 1


        adcLCDdisplay(ADC_value_front);      // display conversion result on the LCD

        if (ADC_value_front > frontThreshold){
            GPIOB -> ODR |= GPIO_ODR_6;     //turn PB6 led on
        
        }else{
            if (ADC_value_left < frontOffThreshold){
            GPIOB -> ODR &= ~GPIO_ODR_6;    //turn PB7 led off
            } else {
            GPIOB -> ODR &= ~GPIO_ODR_6;
            }    //turn PB6 led off
        }
        

        /*
            read ADC for right sensor
        */
        ADC1->CHSELR  |=  ADC_CHSELR_CHSEL2;  // select ADC channel 2(for ADC_IN2 = PA2)
        ADC1->CR  |=  ADC_CR_ADSTART;  // start conversion
        while( (ADC1->ISR & ADC_ISR_EOC) == 0 );  // wait until conversion is complete
        ADC_value_right = ADC1->DR;
        ADC1->CHSELR  &= ~ADC_CHSELR_CHSEL2; // deselect ADC channel 2


        if (ADC_value_right > rightThreshold){
            GPIOB -> ODR |= GPIO_ODR_5;     //turn PB5 led on
        }else{
            if (ADC_value_left < rightOffThreshold){
            GPIOB -> ODR &= ~GPIO_ODR_5;    //turn PB7 led off
            } else {
            GPIOB -> ODR &= ~GPIO_ODR_5;
            }    //turn PB5 led off
        }
    }          
} 

//====================================================================
// FUNCTION DEFINITIONS
//====================================================================
void init_GPIOA(void) { 
    RCC -> AHBENR |= RCC_AHBENR_GPIOAEN; // enable clock signal to Port A
    GPIOA -> MODER |= GPIO_MODER_MODER0;  // configure pin PA0 to analog input mode
    GPIOA -> MODER |= GPIO_MODER_MODER1;  // configure pin PA1 to analog input mode
    GPIOA -> MODER |= GPIO_MODER_MODER2;  // configure pin PA2 to analog input mode

} 

void init_GPIOB(void){
    RCC -> AHBENR |= RCC_AHBENR_GPIOBEN; // enable clock to GPIOB
    GPIOB -> MODER |= GPIO_MODER_MODER5_0;  // set PB5 to output mode
    GPIOB -> MODER |= GPIO_MODER_MODER6_0;  // set PB6 to output mode
    GPIOB -> MODER |= GPIO_MODER_MODER7_0;  // set PB7 to output mode

    GPIOB -> ODR &= ~GPIO_ODR_5;
    GPIOB -> ODR &= ~GPIO_ODR_6;
    GPIOB -> ODR &= ~GPIO_ODR_7;    
}

void init_ADC(void) { 
    ADC1->CR &= ~ADC_CR_ADEN;  // ensure ADC is disabled before calibration
    ADC1->CR |= ADC_CR_ADCAL;  // initiate ADC calibration

    RCC->APB2ENR  |=  RCC_APB2ENR_ADCEN;  // connect ADC to APB clock

    ADC1->CFGR1  |= 0b0000;  // configure ADC to res of 12bits
    ADC1->CFGR1  &= ~ADC_CFGR1_CONT;  // set to single conversion mode

    ADC1->CR  |=  ADC_CR_ADEN;  // enable ADC           
    while ( (ADC1->ISR & ADC_ISR_ADRDY) == 0 ){ }  // exit when ADC has stabilizeD
}


//********************************************************************
// END OF PROGRAM
//********************************************************************
